A Python/ThreeJS bridge utilizing the Jupyter widget infrastructure.


