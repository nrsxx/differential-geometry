npm_pkg_name = 'jupyter-threejs'
py_pkg_name = 'pythreejs'

