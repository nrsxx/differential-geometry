/**
 * The version of the Jupyter data widgets attribute spec that this package
 * implements.
 */
export declare const EXTENSION_SPEC_VERSION = "4.0.0";
/**
 * The current package version.
 */
export declare const version: any;
