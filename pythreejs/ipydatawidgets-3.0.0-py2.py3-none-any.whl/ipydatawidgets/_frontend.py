
module_name = "jupyter-datawidgets"
EXTENSION_SPEC_VERSION = "~4.0.0"
